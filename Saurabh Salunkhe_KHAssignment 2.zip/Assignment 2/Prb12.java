class Prb12
{
public static void main(String arg[])
	{
         
	for(int i=6;i>=1;i--)
		{		
                for(int p=6;p>i;p--)
		{
                 System.out.print(" ");
		}
                for(int j=1;j<=i;j++)
		{
                 System.out.print("* ");
      		}
      		
               System.out.println();
		}
	}
}