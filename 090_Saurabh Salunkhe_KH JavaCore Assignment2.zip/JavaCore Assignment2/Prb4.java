import java.util.Scanner;
class Prb4
{
	
	public static void main(String arg[])
	{
        System.out.println("Enter element in series");
	Scanner sc=new Scanner(System.in);
	int n=sc.nextInt();
        int p=2*n;
        int z=0;
	
	for(int i=1;i<=n;i++)
	{
	z=z+i*10 ;
	}
       int x=p+z;
System.out.println(x);
	}
}