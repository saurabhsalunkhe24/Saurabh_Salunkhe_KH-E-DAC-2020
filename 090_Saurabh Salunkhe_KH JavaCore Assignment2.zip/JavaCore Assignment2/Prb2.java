import java.util.Scanner;
class Prb2
{
	
	public static void main(String arg[])
	{
        System.out.println("Enter number");
	Scanner sc=new Scanner(System.in);
  	int n=sc.nextInt();
        int temp;
        temp=n;
        int c=0;
        while(temp!=0)
        {
        int digit=temp%10;
        c=c*10+digit;
        temp=temp/10;
        }
System.out.println("Reverse of number "+n+" is "+c);
	}
}