import java.util.Scanner;
class Prb5
{
	
	public static void main(String arg[])//12+22+32+42+.........+n2
	{
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter range to find prime number in that range");
        System.out.println("From");
  	int a=sc.nextInt();
        System.out.println("to");
  	int b=sc.nextInt();
        System.out.println("Prime number in given range are");
        for(int k=a;k<=b;k++)
       {
         int c=0;
        for(int i=1;i<=k;i++)
        {
         if(k%i==0)
          c++;
        }
        if(c==2 && k!=1)
        System.out.println(k);
        }
      
	}
}