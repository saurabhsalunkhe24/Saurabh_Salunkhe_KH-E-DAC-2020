import java.util.Scanner;
class Prb8
{
public static void main(String arg[])
{
  	  Scanner sc=new Scanner(System.in);
    	  System.out.println("Size of array");
    	  int n=sc.nextInt();
 	  int a[]=new int[n];
          int c[]=new int[n];
   	  int sum=0;
          
 	for(int i=0;i<n;i++)
 		{
     		System.out.print(i+"No.");
     		a[i]=sc.nextInt();
 			
		}
    
 		
	for(int i=0;i<n;i++)
 		{

                 c[i]=a[n-1-i];
                System.out.print(c[i]+" ");

		}
       
        
        }
}
