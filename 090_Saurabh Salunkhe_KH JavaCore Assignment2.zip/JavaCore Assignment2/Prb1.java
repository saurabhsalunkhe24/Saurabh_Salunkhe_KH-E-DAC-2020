import java.util.Scanner;
class Prb1
{
	
	public static void main(String arg[])
	{
        System.out.println("Enter number");
	Scanner sc=new Scanner(System.in);
	int No=sc.nextInt();
	System.out.println("Table of number "+No+" is");
	for(int i=1;i<=10;i++)
	{
	System.out.println(No+" X "+i+" = "+(No*i));
	}
	}
}