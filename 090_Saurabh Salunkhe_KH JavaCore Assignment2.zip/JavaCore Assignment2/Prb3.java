import java.util.Scanner;
class Prb3
{
	
	public static void main(String arg[])
	{
        System.out.println("Enter number");
	Scanner sc=new Scanner(System.in);
  	int n=sc.nextInt();
        int c=0;
        for(int i=1;i<=n;i++)
        {
         if(n%i==0)
          c++;
        }
       if(c==2 && n!=1)
     System.out.println(n+" is a Prime number");
     else
     System.out.println(n+" is not a Prime number");
	}
}