/*
 * Here comes the text of your license
 * Each line should be prefixed with  * 
 */
package OOPS.exceptionHandling;

/**
 *
 * @author naman
 */
public class tpppp {
    
    public  static void main(String args[]){
        try{
        try{
        
        System.out.println("getting Devide by zero error");
        int b = 30/0;
       /* int a = 30;
        int c = 0;
        int d;
        d = a/c;
        */
        
        }
        catch(ArithmeticException e){
        System.out.println(e);
        }
        //int a[] = {1,2,3,4};
        try{
            int[] arr=new int[2];
            arr[1] = 1;
            arr[2]=2;
            
        System.out.println("array"+arr[6]);
        }
        catch(ArrayIndexOutOfBoundsException e){
        System.out.println("abc"+e);
        System.out.println( );
        }
        }
        catch(Exception e){
        System.out.println(e);
        System.out.println("handled");
        }
        System.out.println("exicution flow maintain");
        
        }
        }
    
