/*
 * Here comes the text of your license
 * Each line should be prefixed with  * 
 */
package OOPS.exceptionHandling;

/**
 *
 * @author naman
 */
public class TryCatch {
    public static void main(String[] args)
    {
       TryCatch tc=new TryCatch();
       ExceptionHandling eh=new ExceptionHandling();
       //OwnExceptionClass  ow=new OwnExceptionClass();
       // eh.finallyCheck();
       //eh.loopCheck();
       //eh.multipleException();
       eh.ownExceptionClass();
    }
}
class ExceptionHandling
{
    int loopCheck()
    {
    for(int i=0;i<5;i++)
    {
        try
        {
            
        System.out.println(100/i);
        }
        catch(Exception a)
        {
            System.out.println("Exception in for loop"+a);
        }
    }
    return 1;
    }
     int div()
        {
            int aa=10,bb=0,cc;
            cc=aa/bb;
            return cc;
        }
     int divpass()
     {
         div();
         return 1;
     }
    int finallyCheck()
    {
        int[] arr=new int[5];
        
        int b=10;
        //getMessage method & finally
        try
        {
            
           int c=10/0;
        }
        catch(ArithmeticException ex)
        {
            System.out.println("\nget message:-   "+ ex.getMessage());
        }
        finally
        {
            System.out.println("\nClosing with catch ____get message");
        }
        //printStackTrace method and finally
       
        try
        {
            divpass();
        }
        catch(Exception exc)
        {
            System.out.println("\n print stack trace "+exc);
             exc.printStackTrace();
        }
        finally
        {
            System.out.println("Closing with catch ____print stack trace");
        }
        //simple try without exception and catch
        try
        {
            int bc=20;
            System.out.println(bc/2); //whenever there is an exception then
                                      //this statement is not executed
        }
        finally
        {
            System.out.println("Closing without catch ____finally only");
        }
        System.out.println("***********************");  
        return 1;
    }
    int multipleException()
    {
        try
        {
            int[] arr=new int[2];
            arr[2]=10;
            int a=arr[2];
            int cd=5/0;
            int sd=7/0;
             System.out.println("Multiple Exception using array___"+a+"\n"+arr.length);    
        }
        catch(ArrayIndexOutOfBoundsException | ArithmeticException aaa )
        {
         System.out.println("Multiple exception in single catch"+aaa);   
        }
       return 1; 
    }
    int ownExceptionClass()
    {
        int integer=16;
        try
        {
            int z=integer/0;
            OwnExceptionClass own=new OwnExceptionClass(16);
            throw own;
        }
        catch(OwnExceptionClass |ArithmeticException own)
        {
            System.out.println(own.getMessage());
             System.out.println("*********"+own);
        }
        return 1;
    }
}
class OwnExceptionClass extends Exception
{
    int except;
    OwnExceptionClass(){}
    OwnExceptionClass(int except)
    {
        //super(except);
        this.except=except;
    }
    @Override
    public String getMessage()
    {
        return "My own defined exception  "+except;
    }
    @Override
    public String toString()
    {
       return "toString printing message overrided  ";   
    }
}
