/*
WAP to define a class Student with attributes rollno, name , 
marks accept data for 2 objects and display them.
 */
package OOPS.Class_Obj;

import java.util.*;
public class Student {
    
    int rollno;
    static String name;
    int marks;
    public static void main(String[] args)
    {
        Data d=new Data();
        d.ipdata();
        d.printdata();
    }
    
}
class Data{
   
    Student student=new Student();
    Student student1=new Student();
    Scanner sc=new Scanner(System.in); 
    void ipdata()
    {
    //Data stddata=new Data();
    //Data stddata1=new Data(); 
       System.out.println("enter name of student=");
        student.name=sc.nextLine();
         System.out.println("enter roll of student=");
        student.rollno=sc.nextInt();
         System.out.println("enter marks of student=");
        student.marks=sc.nextInt();
         System.out.println("enter name of student1=");
         sc.nextLine();
        student1.name=sc.nextLine();
        System.out.println("enter roll of student1=");
        student1.rollno=sc.nextInt();
        System.out.println("enter marks of student1=");
        student1.marks=sc.nextInt();   
        return;
    }
    
    void printdata()
    {
        System.out.println("data of student=");  
        System.out.println(Student.name);
        System.out.println(student.rollno);
        System.out.println(student.marks);
      System.out.println("data of student1=");  
        System.out.println(student1.name);
        System.out.println(student1.rollno);
        System.out.println(student1.marks);
        return;
    }
}