/*
WAP to create a class book with attributes id,name,price
accept data for 5 objects display book with highest price. 
 */
package OOPS.Class_Obj;

import java.util.*;

public class Book {
    static int count=0;
    static int size;
    static double[] maxprice;
        Book(){}
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        System.out.println("enter array of object size = ");
         size=sc.nextInt(); //size of array
         maxprice=new double[size];
        BookData bd[]=new BookData[size];
        BookData bd1=new BookData();//array of obj created.
        //creating and initializing actual bookdata objects using constructor. 
        for(int i=0;i<bd.length;i++)
        {
            System.out.println("enter Book "+i+" Id = ");
            int bkid=sc.nextInt();
            sc.nextLine();
            System.out.println("enter Book "+i+" Name = ");
            String bkname=sc.nextLine();
            System.out.println("enter Book "+i+" Price = ");
            double[] bkprice=new double[bd.length];
            bkprice[i]=sc.nextInt();
            double bkp=bkprice[i];
            maxprice[i]=bkp;
            bd[i]=new BookData(bkid,bkname,bkprice[i]);
            count++;
        }
        for(int i=0;i<bd.length;i++)
        {
            bd[i].getData();
           
        }
        double max=maxprice[0];
        for(int i=0;i<Book.count;i++)
         {
             if(maxprice[i]>max)
                {
                    max=maxprice[i];
                }
         }
        for(int i=0;i<Book.count;i++)
        {
            if(max==maxprice[i])
            {
                System.out.println("This is the book with Highest Price = ");
                System.out.println(bd[i].getData());
            }
             if(i==bd.length-1){
            bd[i].maxPrice();
            }
        }
        
        }   
}

class BookData{ 
int id;
String name;
double price;
BookData(){}
//Scanner sc=new Scanner(System.in);

BookData(int bkid,String bkname,double bkprice){
id=bkid;
name=bkname;
price=bkprice;
//Book book=new Book();
}
int getData()
{
    System.out.println(" Book name= "+name+" Book id= "+ id+" Book price= "+price);
    return 1;
}
void maxPrice()
{
    double temp=0;
   for(int i=0;i<Book.count;i++)
   {
       for(int j=i+1;j<Book.count;j++)
       {
         if(Book.maxprice[j]>Book.maxprice[i])
        {
          temp=Book.maxprice[i];
          Book.maxprice[i]=Book.maxprice[j];
          Book.maxprice[j]=temp;   
        }
       }
   }
   System.out.println("Book Maxprice ="+Book.maxprice[0]);
}
    
}