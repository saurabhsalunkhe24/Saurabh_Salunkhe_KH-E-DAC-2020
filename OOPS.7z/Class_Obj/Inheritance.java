/*
Inheritance---  1). use of parent-child and extend keyword.
                2). Constructor calling using Super Keyword.
                3). method calling & using super ketyword in methods.
                4). method overloading & method overriding.
final keyword---1). final in variable.
                2). final in method.
                3). final in class.
Abstract keyword in method / class in ---- inheritance.
 */
package OOPS.Class_Obj;


public class Inheritance {
    public static void main(String[] args)
    {
        Soup s=new Soup();
        Gujarati g=new Gujarati();
        Maharashtra mh=new Maharashtra();
        Southindian si=new Southindian();
        Punjabi pj=new Punjabi();
        Noodle n=new Noodle();
        Rice r=new Rice();
        s.menu();
        g.menu();
        System.out.println("****************************************************");
        g.indian_cuisine();
        System.out.println("_____________________________________________________");
        mh.maharashtra_cuisine();
        si.southindian_cuisine();
        pj.punjabi_cuisine();
        g.Gujarati_cuisine();
        System.out.println("****************************************************");
        s.Chinese_cuisine();
        System.out.println("_____________________________________________________");
        n.Noodle_cuisine();
        r.Rice_cuisine();
        s.soup_cuisine();
        
        
    }
}


class Cuisine1
{
    Cuisine1(){}
     int w;
    Cuisine1(int y)
    {
        this.w=32;
    } 
    
   /* final */int menu()       //method overriding
    {
      int Total_cuisine=2;
      System.out.println("Here is your menue = "+Total_cuisine);
      return Total_cuisine;
    }
    int desert1()
    {
        int des=25;
        System.out.println("desert"+des);
        return des;
    }
    
} 
/* final */class indian extends Cuisine1
{
    
    int a;
    int b;
    final int h=9;
    indian(int x)
    {
        //super(23);
       this.a=x;
       this.b=10;
    }
    @Override
    int menu()     //method overriden
    {
        int aa=111;
        int bb=222;
        System.out.println("aa"+"bb");
        return aa;
    }
    int indian_cuisine()
    {
        int Total_cuisine=4;
        System.out.println("Here is your Indian Cuisine = "+Total_cuisine);
        return Total_cuisine;
    }
    int desert( int x, int y, int z)       
    {
        int i=x;
        int j=y;
        int k=z;
        System.out.println(i+" "+j+" "+k);
        return i;
    }
    int desert( int x, int y)                //overloading
    {
        super.desert1();
        int i=x;
        int j=y;
        //int k=z;
        System.out.println(i+" "+j);
        return i;
    }
   
}

 abstract class Chinese extends Cuisine1
{
    int s,d,f;
    Chinese(int s,int d,int f)
    {
        this.s=s;
        this.f=f;
        this.d=d;
    }
    int Chinese_cuisine()
    {
        int Total_cuisine=3;
        System.out.println("Here is your Chinese Cuisine = "+Total_cuisine);
        return Total_cuisine;
    }
    abstract int eat();
}
class Maharashtra extends indian
{   
    Maharashtra()
    {
     super(39);   
    } 
    int maharashtra_cuisine()
    {
        int Total_cuisine=3;
        System.out.println("Here is your Maharashtra Cuisine = "+Total_cuisine+"\n 1.kolhapuri \n 2.kokani \n 3.khandeshi ");
        return Total_cuisine;
    }
}
class Southindian extends indian
{
    Southindian()
    {
        super(40);
    }
    int southindian_cuisine()
    {
        int Total_cuisine=3;
        System.out.println("Here is your South-Indian Cuisine = "+Total_cuisine+" \n 1.Idlee \n 2.Dosa \n 3.Utappa ");
        return Total_cuisine;
    }
} 
class Punjabi extends indian
{
    Punjabi()
    {
        super(21);
    }
    int punjabi_cuisine()
    {
        int Total_cuisine=2;
        System.out.println("Here is your Punjabi Cuisine = "+Total_cuisine+"\n 1.Chiken Tandoori \n 2.Chicken Tikka ");
        return Total_cuisine;
    }
}  
class Gujarati extends indian
{
    Gujarati()
    {
        super(11);
    }
 int Gujarati_cuisine()
    {
        int Total_cuisine=2;
        System.out.println("Here is your Gujarati Cuisine = "+Total_cuisine+"\n 1.Dhokala 2.Fafada ");
        return Total_cuisine;
    }   
}
class Rice extends Chinese
{
    Rice()
    {
        super(56,67,78);
    }
int Rice_cuisine()
    {
        int Total_cuisine=2;
        System.out.println("Here is your Chinese Rice Cuisine = "+Total_cuisine+"\n 1.schezawan rice 2.garlic chicken rice");
        return Total_cuisine;
    }
    @Override
  int eat()
{
    int i=10;
    System.out.println("bhasmasur"+i);
    return i;
}
}
class Noodle extends Chinese
{
    Noodle()
    {
        super(34,45,56);
    }
    int Noodle_cuisine()
    {
        int Total_cuisine=2;
        System.out.println("Here is your Chinese Noodle Cuisine = "+Total_cuisine+"\n 1.chiken hakka \n 2.chiken tripple");
        return Total_cuisine;
    }
    @Override
    int eat()
{
    int i=20;
    System.out.println("bhasmasur"+i);
    return i;
}
}
class Soup extends Chinese
{
    Soup()
    {
        super(11,22,33);
    }
    int soup_cuisine()
    {
        int Total_cuisine=3;
        System.out.println("Here is your Soup Cuisine = "+Total_cuisine+"\n 1.chicken clear soup \n 2.chicken manchow \n 3.chicken noodle");
        return Total_cuisine;
    }
    @Override
    int eat()
{
    int i=13;
    System.out.println("bhasmasur"+i);
    return i;
}
}
