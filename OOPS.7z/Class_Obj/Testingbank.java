/*
 * Here comes the text of your license
 * Each line should be prefixed with  * 
 */
package OOPS.Class_Obj;

/**
 *
 * @author naman
 */import java.util.*;


class Testingbank
{ 
     int ac_no;
     String name , type ;
     float amount ;
     void details ( int no , String nm, String t, float a )
    {
      ac_no= no;
      name=nm;
      type=t;
      amount=a;
    }
   void show()
    {
      System.out.println(ac_no+" "+name+" "+type+" "+amount);
     }
   void deposite (float a)
    {
     amount=amount+a;
     System.out.println("Deposite amount:"+a);
    }
   void withdraw(float a)
     {
       if (amount<a)
       System.out.println(" Balance is Insufficient");
       else 
       amount=amount-a;
       System.out.println(" Withdraw amount:"+a);
      }
     void checkbalance()
     {
      System.out.println(" Balance is :"+amount);
    }
}
  class Test{
  public static void main(String args[])
{
  Testingbank b = new Testingbank();
  b.details(12345, "Abhishek","Saving",500);
  b.show();
  b.deposite(20000);
  b.checkbalance();
  b.withdraw(500);
  b.checkbalance();
 }
}

