/*
WAP to define Class Simpleinterest with attributes principalamount, 
 rate of interest static ,number of years calculate SI and display it. 
 */
package OOPS.Class_Obj;

import java.util.*;

public class Simpleinterest {
    
    int principal;
    double interestRate=0.12;
    int years;
    public static void main(String[] args)
    {
         Calculation cal=new Calculation();
         cal.calculate();
       
    }
}
class Calculation
{
    Simpleinterest si=new Simpleinterest();
    Scanner sc=new Scanner(System.in);
    double calculate()
    {
        System.out.println("Enter Principal amount = ");
        si.principal=sc.nextInt();
        System.out.println("Enter Years = ");
        si.years=sc.nextInt();
        System.out.println("Rate of interest is "+si.interestRate);
        double amount=(double)si.principal*((1+(si.interestRate*(double)si.years)));
        System.out.println("Final Amount = "+amount);
        return amount;
    }
}