/*

1]. creation of packge/ .jar file./ importing packeges.
2]. Static variable/block/method.
3]. *this* constructor./zero argument/argument constructor/calling any(type i.e. zero,argument)
    constructor inside any constructor./constructor chaining.
4]. Method overloading.---pass by value(primtive data type)/pass by reference(non primptive)i.e. objects.
5]. Inheritance--- 1). use of parent-child and extend keyword.
                   2). Constructor calling using Super Keyword.
                   3). method calling & using super ketyword in methods.
                   4). method overloading & method overriding.
6]. final keyword---1). final in variable.
                   2). final in method.
                   3). final in class.
7]. Access specifier--- public / private / protected / default.
8]. Abstract keyword in method / class in ---- inheritance.

 */
package OOPS.Class_Obj;


public class OOPS_Week2 {
    public static void main(String[] args)
    {
       /* Point1 p=new Point1();//point1 class object is created.
        Point1 p1=new Point1(60);
        Point1 p2=new Point1(100,120);
        Point1.age();//call by class name as method is static.
        p1.parent_age();
        p.parent_age(); */
     /* method m=new method();
        m.method1(10, 20);
        m.method1(50,60,70);// pass by value ***(with the help of reference i think)
        m.method1(m);   //pass by reference of the object
     */
        Cuisine cu=new Cuisine(30,120);
        //Cuisine cu1=new Cuisine(30,12,45);
        Maharashtrian mh=new Maharashtrian();
        mh.print_price();
        mh.print_area();
        mh.menu();
        
    }
    
}
/*
class Point1{
    
    static int a=10;    //static variable intitiallised.
    static int b;       //static variable not intitiallised.
    int c;
    int d; 
    static{             //static block
                b=20;   //static block used to intitiallise satic variable. 
          }
    static int age()
    {
        int age_son=b;
        System.out.println("age of son="+b);
        return age_son;
    }
    Point1()            //zero argument construtor for initiallizing c.
    {
         c=50;
         System.out.println("zero args "+c);
    }
    Point1(int d)       //argument constructor for initiallizing d.
    {
        this();
        this.d=d;
        System.out.println("one args "+d);
    }
    Point1(int e, int f)       //argument constructor for initiallizing d.
    {
        this(e);
        System.out.println("dual arg constructor");
    }
    void parent_age()
    {
        System.out.println("method "+c);
    }
    
    
} */
/*
class method
{   //primptive method overloading
    int method1(int nam, int pat)
    {
        int x=nam;
        int y=pat;
        System.out.println("method 1 "+x+" "+y);
        return x;
    }
    int method1(int fo, int lo, int go)
    {
        int f=fo;
        int l=lo;
        System.out.println("method 1 "+f+" "+l);
        return f; 
    }
    //non primptive method over loading
     method method1(method t)
    {
        int x=10;
        int y=20;
        System.out.println("method 1 "+x+" "+y+" "+t);
        return t;
    }
    
    
}
*/

class Cuisine
{
    int a;
    int b;
    Cuisine()
                {
                    a=20;//no of tables
                    b=80;//no of chairs
                    System.out.println("in parent zero constructor");
                }
    Cuisine(int a, int b)
    {
        this.a=a;
        this.b=b;
        System.out.println("in parent grandfather args constructor");
    }
    int menu()
    {
        int i=110;// advance booking
        System.out.println("Booking ="+i);
        return i;
    }
}

class Indian extends Cuisine
{
    int area;
    Indian(int w,int e,int r)
    {
        //super(10,20);
        System.out.println("in parent father args constructor");
        area=4;
    }
    
    int print_area()
    {
       int choice=1;
        System.out.println("1. Maharashtra \n 2.south indian \n  3.gujarati \n 4.punjabi");
        return choice;
    }
}
class Maharashtrian extends Indian
{   
    int price;
    Maharashtrian()
    {
        super(30,40,50);
       price=250;
        System.out.println("in parent son zero constructor");
        
    }
    int print_price()
    {
        int price=300;
        System.out.println("maharshtrian thaali = "+price);
        return price;
    }
}