
package OOPS.Class_Obj;

import java.util.Scanner;

public class Bank {
    private String no;
    private String name;
    private String id;
    int reservBal=500;
    int accBal=2000-500;
   
    //int accBal2=minBal-Bank.withdrwal();
    
    void userIp(String accNo,String userName, String userId)
    {
         no = accNo;
         name = userName;
         id = userId; 
         
    }
    void display(){
    System.out.println("Details Filled By User"); 
    System.out.println("User Account Number:-"+no);
    System.out.println("User Full Name:-"+name);
    System.out.println("User Id:-"+id);
    }
    
    public int deposit()
    {    
        
        //System.out.println("Deposit Amount:-"); 
        Scanner sc=new Scanner(System.in);
        accBal = accBal+sc.nextInt();
        //System.out.println("Account Balance After Deposit:-"+(deposit+500));
        return 1;        
    }
    
     public int withdrawl()
    {
     //System.out.println("Withdrawl Amount:-");
     Scanner sc=new Scanner(System.in);
      Bank bank = new Bank();
     int i=sc.nextInt();
     int balanceW=0;
         
     if(accBal>i)             
     {
     balanceW=accBal-i;
     System.out.println("Amount Withdrawn="+i);
     System.out.println("Account Balance after Withdrwal:-"+balanceW);
     
     }
     else
     {
         System.out.println("insuffficient balance");
     }//System.out.println("Amount withdrawn:-"+withdrawl);
     accBal=balanceW;
     return accBal;
    }
    
    int accbal()
    {
       /* Bank bank = new Bank();
        System.out.println("Enter the amount you want to deposit:-");
        int j=deposit();
        int deposite=j+accBal;
        System.out.println("Enter the amount you want to withdraw:-");
        int k=bank.withdrawl();
        int withdrawl=accBal-k;
        int balancecheck=((deposite)-withdrawl)+accBal;*/
        System.out.println("Your Account Balance is;-"+accBal);
        return accBal;
    }

    public static void main(String args[])
    {
        Scanner sc=new Scanner(System.in);
        Bank bank = new Bank();
        System.out.println("User Account Number:-");
        String accNo=sc.next();
        System.out.println("User Full Name:-");
        String userName=sc.next();
        System.out.println("User Id:-");
        String userId=sc.next();
        bank.userIp(accNo,userName,userId);
        bank.display();
        System.out.println("Select An Optin From Below\n"+"1.Deposit\n"
                + "2.Withdrawl\n"
                + "3.Check Bal\n"
                + "4.Exit\n");
        int options=sc.nextInt();
        
        switch (options)
        {
            case 1:
                System.out.println("Account Balance After Deposit:-"+(bank.deposit()));               
               break;
            case 2:
              bank.withdrawl();
              break;
            case 3:
               bank.accbal();
               break;
            case 4:
                break;
            default:
                  System.out.println("Invalid Input!");
                
        }
        
        
        
            
    }
    
    
    
}
