/*
 * Here comes the text of your license
 * Each line should be prefixed with  * 
 */
package OOPS.Class_Obj;
import java.util.Scanner;
    public class Studentclass {
        int roll_no;
        String name;
        double marks;

        void display(int rm,String s,double m)
        {
            roll_no=rm;
            name=s;
            marks=m;
            System.out.println(roll_no +"  " + name+ " " + marks);
        }

        public static void main(String[] args) {
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter the no of students:");
            int n =sc.nextInt();
            Studentclass stud[]=new Studentclass[n];
            int rm=0;
            String s=null;
            double m=0;
            for(int i=0;i<n;i++)
            {
                stud[i]=new Studentclass();
                
                 rm=sc.nextInt();
                 sc.nextLine();
                 s=sc.nextLine();
                 m=sc.nextDouble();
                
            }
            
            	for(int i=0;i<n;i++) 
            	{
            	stud[i].display(rm,s,m);
            	}
            
        }
    }
    
