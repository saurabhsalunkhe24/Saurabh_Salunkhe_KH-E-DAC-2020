import java.util.*;
class Prb10
{
private static Scanner sc;
public static void main(String arg[])
	{
         System.out.println("Enter temperature in Fahrenheit");
         sc=new Scanner(System.in);
         float t=sc.nextFloat();
         float c= 5*(t-32)/9 ;
         
System.out.println(" temperature "+t+" in degree celcius is "+c);
	}

}