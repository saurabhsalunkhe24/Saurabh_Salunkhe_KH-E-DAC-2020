import java.util.*;
public class Prb13b
 {
	
		public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter  three Numbers:");
			int a=sc.nextInt();
			int b=sc.nextInt();
			int c=sc.nextInt();
		
			String z=(a>b && a>c)? a+" is Greater" :(b>c && b>a)? b+" is greater ": c+" is greater";
			System.out.println(z);
	
		
		}
		
}