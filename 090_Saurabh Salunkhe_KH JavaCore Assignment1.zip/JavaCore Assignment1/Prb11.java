import java.util.*;   
class Prb11 //swaping of two number
{ 
private static Scanner sc;
public static void main(String arg[])
{
System.out.println("Enter two number for swapping");   
sc=new Scanner(System.in);

    int x =sc.nextInt();
    int y =sc.nextInt();
System.out.println("before swapping "+x+" "+y);
    // Code to swap 'x' and 'y'
    x = x + y; // x now becomes 15
    y = x - y; // y becomes 10
    x = x - y; // x becomes 5
System.out.println("After swapping "+x+" "+y);
}
}