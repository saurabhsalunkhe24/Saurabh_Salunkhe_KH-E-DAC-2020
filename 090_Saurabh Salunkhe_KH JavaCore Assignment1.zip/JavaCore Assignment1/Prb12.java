import java.util.*;
public class Prb12 {
	
		public static void main(String[] args) {
			
			Scanner sc=new Scanner(System.in);
			System.out.print("Enter your salary :");
			double basicSal=sc.nextFloat();
			double HRA = 0,DA = 0,GS;
			if(basicSal<10000) {
				HRA=basicSal * 0.1;
				DA=basicSal * 0.9;
				
			}
			if(basicSal>=10000) {
				 HRA=2000;
				 DA=basicSal * 0.98;
			}
			GS=basicSal + DA + HRA;
		System.out.println("Your Gross Salary is Rs."+GS);
		}
		
}
