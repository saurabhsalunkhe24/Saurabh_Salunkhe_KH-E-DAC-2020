import java.util.*;
public class Prb15
 {
	
		public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);
			System.out.print("Enter your Gender(M/F) :");
			char gender=sc.next().toUpperCase().charAt(0);
			if(gender=='M' || gender=='F') {
			System.out.print("Enter your age :");}
			else
			{
				System.out.println("IMVALID INPUT");
				
			}
			int age=sc.nextInt();
			
			if(gender=='M' && age>18 ) {
				System.out.println("Gender = MALE");
				System.out.println("ELIGIBLE FOR MARRIAGE");
			}else if( gender=='F' && age>18) {
				System.out.println("Gender= FEMALE");
				System.out.println("ELIGIBLE FOR MARRIAGE");
			}
			
			
	
		
		}
		
}