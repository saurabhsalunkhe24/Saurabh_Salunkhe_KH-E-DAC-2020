class Prb5
{
public static void main(String arg[])
{
String s1= arg[0];

System.out.println("Wellcome "+s1);
}

}
