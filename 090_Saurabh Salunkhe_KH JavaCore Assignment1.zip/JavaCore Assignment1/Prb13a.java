import java.util.*;
public class Prb13a//using if else
{

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter  three Numbers:");
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c=sc.nextInt();
		if(a>b && a>c) {
			System.out.println(a+" is Greater");
		}else if(b>c) {
			System.out.println(b+" is Greater ");
		}else
		{
			System.out.println(c+" is Greater");
		}
		
	}
		
				
}
