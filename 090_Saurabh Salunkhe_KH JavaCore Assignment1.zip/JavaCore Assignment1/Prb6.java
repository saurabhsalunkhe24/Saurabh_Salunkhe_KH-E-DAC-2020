import java.util.Scanner;
class Prb6
{
   public static void main(String arg[])
    {
     Scanner sc=new Scanner(System.in);
     System.out.println("please enter radius of circle");
     float pi=3.14f;
     float radius=sc.nextFloat();
     float area;
     float circumferance;
     area=pi*radius*radius;
     circumferance=2*pi*radius;
     System.out.println("Area and Cirumferance of circle having radius "+radius+" is "+area+ " and "+circumferance);
    }
}