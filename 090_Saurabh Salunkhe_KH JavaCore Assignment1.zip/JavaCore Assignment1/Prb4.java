import java.util.Scanner;
class Prb4
{
   public static void main(String arg[])
    {
     Scanner sc=new Scanner(System.in);
     System.out.println("please enter two number");
     byte x=sc.nextByte();
     byte y=sc.nextByte(),z;
     z=(byte)(x+y);
     System.out.println("sum "+z);
    }
}