import java.util.*;
public class Prb3
 {
	static void ex1(int x)
	{
		int y=x*x +3*x -7;
		System.out.println("A. y = x*x + 3x -7 = "+y);
	}
	
	static void ex2(int x)
	{
	int y=x++ + ++x;
	System.out.println("B. y = x++ + ++x ");
	System.out.println("x = "+x+"      y = "+y);
	}
	
	static void ex3(int x,int y) {
		int z= x++ - --y - --x + x++;
		System.out.println("C. z = x++ - --y - --x + x++ ");
		System.out.println("x = "+x+"     y = "+y+"     z = "+z);
	}
	
	static void  ex4(int a,int b) {
		
	}
	
	public static void main(String[] args)
 {
	
	Scanner sc=new Scanner(System.in);
	
	int x=sc.nextInt();
	int y=sc.nextInt();
	ex1(x);
	System.out.println("----------------------------");
	ex2(x);	
	System.out.println("----------------------------");
	ex3(x,y);
	System.out.println("----------------------------");
	
	boolean z,a=true,b=false;
	z=(a  &&  b || !(a  ||  b ));
	System.out.println("Z = x && y || !(x || y)");
	System.out.println("Z = "+z);
	
	}
}