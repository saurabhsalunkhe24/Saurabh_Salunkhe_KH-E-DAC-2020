package project;
import java.util.Scanner;

public class Demo
{
    public static void main(String arg[])
    {
        Car1 obj=new Car1();
        Scanner sc=new Scanner(System.in);
        System.out.println("-----------------------------*Welcome in CDAC Parking LOT*---------------------------------");
        while(true)
        {
            System.out.println("-----------------------------------------------------------------------------------------");
            System.out.println("Menu");
            System.out.println(" 1. Park Car");
            System.out.println(" 2. UnPark Car");
            System.out.println(" 3. Display Car List ");
            System.out.println(" 4. Exit");
            System.out.println("-----------------------------------------------------------------------------------------");
            int x;
            System.out.println("Enter choice :");
            x=sc.nextInt();

            switch(x)
            {
                case 1:
                    obj.parkCar();
                    break;
                case 2:
                    System.out.println("Enter your mobile number");
                    Long no=sc.nextLong();
                    obj.carUnPark(no);
                    break;
                case 3:
                    System.out.println("Display Car List ");
                    obj.displayCarPark();
                    break;
                case 4: System.exit(0);
                    break;
                default :
                    System.out.println("Entry Invalid , Choose appropriate option");
                    break;
            }
        }
    }
}

