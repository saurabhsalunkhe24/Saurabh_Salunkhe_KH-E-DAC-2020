package project;

import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

class Car1 {
    Scanner sc=new Scanner(System.in);
    String carBrand;
    String carNo;
    long mobile;
    int size=10;
    int c=0;
    char ch;
    long diffHours;
    DoubblyLinkedList list=new DoubblyLinkedList();
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
    LocalDateTime now = LocalDateTime.now();

    Car1()
    {

    }
    public Car1(String brand,String no,long mo)
    {
        carBrand=brand;
        carNo=no;
        mobile=mo;
    }
    public void parkCar()
    {
        if(c<=size) {
            System.out.println("Please pay deposit Rs. 5 ");
            System.out.println("Would you like to pay deposit Rs. 5 Y/N");
            ch=sc.next().charAt(0);
            if(ch=='y'|| ch=='Y'){
                System.out.println("Enter car details :-");
                System.out.println("1. Enter Mobile Number:");
                long mobile = sc.nextLong();
                sc.nextLine();
                System.out.println("2. Enter Car Brand :");
                String br = sc.nextLine();
                System.out.println("3. Enter Car Number:");
                String n = sc.nextLine();
                String ti=dtf.format(now);


                list.insert(br, n, mobile,ti);
                c++;
            }
            else{
                System.out.println("Sorry Without payment we cant't park your car");
            }

        }
        else
            System.out.println("Sorry for inconvience ; No space in parking lot \n Thank u for visiting us :) ");
    }
    public void carUnPark(long number) {

        int p = list.searching(number);

        String to = dtf.format(now);
        String ti = list.searchTime(number);
        SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
        if(ti.equals("0000/00/00 00:00:00"))
        {

        }
        else
        {
            Date d1 = null;
            Date d2 = null;
            try {
                d1 = format.parse(ti);
                d2 = format.parse(to);
                long diff = d2.getTime() - d1.getTime();
                diffHours = diff / (60 * 60 * 1000) % 24;
                System.out.print(diffHours + " hours, ");
                long amount = diffHours * 5;
                if (diffHours == 0 ) {
                    list.deleteAt(p);
                    c--;
                    System.out.println("Thank you for visiting us. :)");
                } else {

                    System.out.println("Please pay " + (amount-5));
                    System.out.println("would you like to pay amount Y/N");
                    ch = sc.next().charAt(0);

                    if (ch == 'y' || ch == 'Y') {
                        list.deleteAt(p);
                        c--;
                    } else {
                        System.out.println("Sorry We can't unpark your car without payment");
                    }

                }
            } catch (Exception e) {
                //e.printStackTrace();
                System.out.println("Thank you for visiting us. :)");
            }

        }

        System.out.println(c);
    }

    public void displayCarPark()
    {if(c==0)
    {
        System.out.println("Parking lot is empty");
    }
    else
        list.displayForward();
    }
}