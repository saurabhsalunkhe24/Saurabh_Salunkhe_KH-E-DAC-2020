package project;
import java.text.SimpleDateFormat;
import java.util.*;
import java.time.format.DateTimeFormatter;
import java.time.LocalDateTime;

public class DoubblyLinkedList {
    Scanner sc=new Scanner(System.in);
    Node1 head;
    Node1 tail;
    int length;

    int size=10;
    int c=1;
    char ch;
    long diffHours;
    //DoubblyLinkedList list=new DoubblyLinkedList();
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
    LocalDateTime now = LocalDateTime.now();


    public void insert(String brand, String no, long mob,String ti) {
        Node1 node = new Node1(brand, no, mob,ti);

        if (head == null) {
            head = tail = node;
            length++;
        } else {
            tail.next = node;
            node.prev = tail;
            tail = node;
            length++;
        }
    }


    public void insertFirst(String brand, String no, long mob,String ti) {
        Node1 node = new Node1(brand, no, mob,ti);
        if (head == null) {
            head = tail = node;
            length++;
        } else {
            node.next = head;
            head.prev = node;
            head = node;
            length++;
        }
    }

    public void insertAt(int pos, String brand, String no, long mob,String ti) {
        Node1 node = new Node1(brand, no, mob,ti);
        if (pos == 1) {
            head = tail = node;
            length++;
        } else {

            int c = (((length - pos) > (pos - 1)) ? 1 : 2);
            switch (c) {
                case 1: {
                    Node1 n = head;
                    for (int i = 1; i < pos - 1; i++) {
                        n = n.next;
                    }
                    node.next = n.next;
                    node.prev = n;
                    n.next.prev = node;
                    n.next = node;
                    length++;
                }
                break;
                case 2: {
                    Node1 n = tail;
                    for (int i = length; i > pos; i--) {
                        n = n.prev;
                    }
                    node.prev = n.prev;
                    node.next = n;
                    n.prev.next = node;
                    n.prev = node;
                    length++;
                }
                break;
            }
        }
    }

    public void delete() {
        if (length == 1) {
            head = tail = null;
            length--;
        } else {
            tail = tail.prev;
            tail.next.prev = null;
            tail.next = null;
            length--;
        }
    }

    public void deleteFirst() {
        if (length == 1) {
            head = tail = null;
            length--;
        } else {
            head = head.next;
            head.prev.next = null;
            head.prev = null;
            length--;
        }
    }

    public void deleteAt(int pos) {
        if (pos == 1) {
            deleteFirst();
            length--;
        } else {
            if (pos == length) {
                delete();
            } else {
                int c = (((length - pos) > (pos - 1)) ? 1 : 2);
                switch (c) {
                    case 1: {
                        Node1 n = head;
                        for (int i = 1; i < pos; i++) {
                            n = n.next;
                        }
                        //                 Node1 n1=n;
                        n.prev.next = n.next;
                        n.next.prev = n.prev;
                        n = null;
                        length--;
                    }
                    break;
                    case 2: {
                        Node1 n = tail;
                        for (int i = length; i > pos; i--) {
                            n = n.prev;
                        }
                        n.prev.next = n.next;
                        n.next.prev = n.prev;
                        n = null;
                        length--;
                    }
                    break;
                }

            }
        }
    }

    public void displayForward() {
        try {
            Node1 n = head;
            while (n.next != null) {
                System.out.println(" Car Brand : "+n.carBrand + "\n Car Number : " + n.carNo + "\n Mobile number of Owner : " + n.mobile+"\n Time : "+n.time);
                n = n.next;
            }

            System.out.println(" Car Brand : "+tail.carBrand + "\n Car Number : " + tail.carNo + "\n Mobile number of Owner : " + tail.mobile+"\n Time : "+tail.time);
        }
        catch(Exception e)
        {
            System.out.println(" Car Brand : "+tail.carBrand + "\n Car Number : " + tail.carNo + "\n Mobile number of Owner : " + tail.mobile+"\n Time : "+tail.time);
        }

    }
    public int searching(long number) {
        int count = 1;
        Node1 n = head;
        try{
            while (n.mobile != number) {
                n = n.next;
                count++;
            }
        }
        catch(Exception e)
        {
            System.out.println("Car not found please check details");
            return count;
        }
        return count;
    }


    public String searchTime(long number) {

        Node1 n = head;
        try {
            while (n.mobile != number) {
                n = n.next;
            }
            return n.time;
        }
        catch(Exception e)
        {

        }
        return "0000/00/00 00:00:00" ;

    }
}