package project;

public class Node1 {
    String carBrand;
    String carNo;
    String time;
    long mobile;

    Node1 prev;
    Node1 next;
    public Node1()
    {

    }
    public Node1(String brand,String no,long mo,String t)
    {
        carBrand=brand;
        carNo=no;
        mobile=mo;
        time=t;
        prev=next=null;
    }
}